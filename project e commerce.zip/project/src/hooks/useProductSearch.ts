import { useState } from 'react';
import { Product } from '../types';
import { getMockProducts } from '../services/mockData';

export const useProductSearch = () => {
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [error, setError] = useState<string | null>(null);

  const searchProducts = async (query: string): Promise<Product[]> => {
    try {
      setIsSearching(true);
      setError(null);

      // In a real app, this would be an API call
      // For this demo, we'll use a mock data service with a delay
      const results = await new Promise<Product[]>((resolve) => {
        setTimeout(() => {
          const allProducts = getMockProducts();
          
          // Simple search logic
          const filtered = allProducts.filter((product) => {
            const lowerQuery = query.toLowerCase();
            return (
              product.name.toLowerCase().includes(lowerQuery) ||
              product.description.toLowerCase().includes(lowerQuery) ||
              product.category.toLowerCase().includes(lowerQuery)
            );
          });
          
          resolve(filtered);
        }, 1000); // Simulate network delay
      });

      setSearchResults(results);
      return results;
    } catch (err) {
      console.error('Error searching products:', err);
      setError('Failed to search products. Please try again.');
      return [];
    } finally {
      setIsSearching(false);
    }
  };

  return {
    searchProducts,
    searchResults,
    isSearching,
    error,
  };
};