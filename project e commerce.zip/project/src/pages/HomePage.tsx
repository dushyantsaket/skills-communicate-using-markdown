import React from 'react';
import { MessageSquare, Search, ShoppingBag, CreditCard, ArrowRight } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const HomePage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="bg-blue-600 text-white rounded-xl overflow-hidden">
        <div className="container mx-auto px-6 py-12 md:py-16 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0 md:pr-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
              Shop Smarter with Our AI Assistant
            </h1>
            <p className="text-blue-100 text-lg mb-6">
              Get personalized product recommendations and instant answers to all your shopping questions.
            </p>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <button 
                onClick={() => navigate(isAuthenticated ? '/products' : '/login')}
                className="bg-white text-blue-600 hover:bg-blue-50 px-6 py-3 rounded-md font-medium transition-colors flex items-center justify-center"
              >
                Start Shopping <ArrowRight className="ml-2 h-5 w-5" />
              </button>
              <button 
                onClick={() => isAuthenticated ? null : navigate('/login')}
                className="bg-blue-700 hover:bg-blue-800 px-6 py-3 rounded-md font-medium transition-colors flex items-center justify-center"
              >
                {isAuthenticated ? 'Try the Chatbot' : 'Sign In'}
              </button>
            </div>
          </div>
          <div className="md:w-1/2">
            <div className="bg-white rounded-lg shadow-lg p-4 text-gray-800">
              <div className="flex items-center border-b pb-3">
                <MessageSquare className="text-blue-600 h-5 w-5 mr-2" />
                <span className="font-medium">ShopChat Assistant</span>
              </div>
              <div className="py-3">
                <div className="bg-gray-100 rounded-lg p-3 mb-3 max-w-[80%]">
                  <p className="text-sm">Hello! I'm your shopping assistant. How can I help you today?</p>
                </div>
                <div className="bg-blue-600 text-white rounded-lg p-3 mb-3 ml-auto max-w-[80%]">
                  <p className="text-sm">I'm looking for wireless headphones under $100.</p>
                </div>
                <div className="bg-gray-100 rounded-lg p-3 max-w-[80%]">
                  <p className="text-sm">I found several options for you. How about these wireless earbuds with noise cancellation?</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">How ShopChat Works</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our intelligent shopping assistant makes finding the perfect products faster and easier than ever.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="bg-blue-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
              <Search className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Intelligent Search</h3>
            <p className="text-gray-600">
              Just describe what you're looking for in natural language, and our AI will find the best matches.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="bg-blue-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
              <ShoppingBag className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Personalized Recommendations</h3>
            <p className="text-gray-600">
              Get tailored product suggestions based on your preferences and previous interactions.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="bg-blue-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
              <CreditCard className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Seamless Checkout</h3>
            <p className="text-gray-600">
              Purchase directly through our chat interface without navigating through multiple pages.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-50 rounded-xl p-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to experience smarter shopping?</h2>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          Sign in to start chatting with our AI shopping assistant and discover products tailored to your needs.
        </p>
        <button 
          onClick={() => navigate(isAuthenticated ? '/products' : '/login')}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md font-medium transition-colors"
        >
          {isAuthenticated ? 'Explore Products' : 'Sign In to Start'}
        </button>
      </section>
    </div>
  );
};

export default HomePage;