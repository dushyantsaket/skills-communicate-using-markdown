import { Product } from '../types';

// Categories
const categories = [
  'Electronics',
  'Clothing',
  'Home & Kitchen',
  'Books',
  'Beauty',
  'Sports',
  'Toys',
  'Health',
];

// Generate random products
export const getMockProducts = (): Product[] => {
  const products: Product[] = [];

  // Electronics
  const electronics = [
    {
      name: 'Wireless Earbuds',
      description: 'True wireless earbuds with noise cancellation and water resistance.',
      price: 99.99,
      category: 'Electronics',
      image: 'https://images.pexels.com/photos/3780681/pexels-photo-3780681.jpeg',
      rating: 4.5,
      stock: 20,
    },
    {
      name: 'Smart Watch',
      description: 'Fitness tracking smartwatch with heart rate monitor and GPS.',
      price: 199.99,
      category: 'Electronics',
      image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg',
      rating: 4.2,
      stock: 15,
    },
    {
      name: 'Bluetooth Speaker',
      description: 'Portable Bluetooth speaker with 24-hour battery life and waterproof design.',
      price: 79.99,
      category: 'Electronics',
      image: 'https://images.pexels.com/photos/1279107/pexels-photo-1279107.jpeg',
      rating: 4.7,
      stock: 25,
    },
    {
      name: 'Ultra HD Smart TV',
      description: '55-inch 4K Smart TV with HDR and built-in streaming apps.',
      price: 699.99,
      category: 'Electronics',
      image: 'https://images.pexels.com/photos/1444416/pexels-photo-1444416.jpeg',
      rating: 4.8,
      stock: 10,
    },
    {
      name: 'Wireless Charging Pad',
      description: 'Fast wireless charging pad compatible with all Qi-enabled devices.',
      price: 29.99,
      category: 'Electronics',
      image: 'https://images.pexels.com/photos/4526407/pexels-photo-4526407.jpeg',
      rating: 4.0,
      stock: 30,
    },
  ];

  // Clothing
  const clothing = [
    {
      name: 'Cotton T-Shirt',
      description: '100% organic cotton t-shirt, comfortable and durable.',
      price: 24.99,
      category: 'Clothing',
      image: 'https://images.pexels.com/photos/4210866/pexels-photo-4210866.jpeg',
      rating: 4.3,
      stock: 50,
    },
    {
      name: 'Slim Fit Jeans',
      description: 'Classic slim fit jeans with stretch denim for comfort.',
      price: 49.99,
      category: 'Clothing',
      image: 'https://images.pexels.com/photos/1082529/pexels-photo-1082529.jpeg',
      rating: 4.4,
      stock: 35,
    },
    {
      name: 'Winter Jacket',
      description: 'Insulated winter jacket with water-resistant outer shell.',
      price: 129.99,
      category: 'Clothing',
      image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg',
      rating: 4.6,
      stock: 20,
    },
  ];

  // Home & Kitchen
  const homeKitchen = [
    {
      name: 'Non-stick Cookware Set',
      description: '10-piece non-stick cookware set with glass lids.',
      price: 89.99,
      category: 'Home & Kitchen',
      image: 'https://images.pexels.com/photos/6996088/pexels-photo-6996088.jpeg',
      rating: 4.5,
      stock: 15,
    },
    {
      name: 'Coffee Maker',
      description: 'Programmable coffee maker with thermal carafe and auto shut-off.',
      price: 69.99,
      category: 'Home & Kitchen',
      image: 'https://images.pexels.com/photos/6205791/pexels-photo-6205791.jpeg',
      rating: 4.7,
      stock: 25,
    },
    {
      name: 'Robot Vacuum',
      description: 'Smart robot vacuum with mapping technology and app control.',
      price: 299.99,
      category: 'Home & Kitchen',
      image: 'https://images.pexels.com/photos/4108286/pexels-photo-4108286.jpeg',
      rating: 4.4,
      stock: 10,
    },
  ];

  // Generate more products
  const allProductTemplates = [...electronics, ...clothing, ...homeKitchen];
  const colors = ['Red', 'Blue', 'Black', 'White', 'Green', 'Purple', 'Orange', 'Gray'];
  const sizes = ['Small', 'Medium', 'Large', 'X-Large', 'XX-Large'];
  const brands = ['TechPro', 'EcoStyle', 'HomeEssentials', 'FitLife', 'LuxuryLiving', 'BookWorm'];

  // Generate 100+ products based on templates with variations
  for (let i = 0; i < 20; i++) {
    for (const template of allProductTemplates) {
      const brand = brands[Math.floor(Math.random() * brands.length)];
      const color = colors[Math.floor(Math.random() * colors.length)];
      const size = template.category === 'Clothing' 
        ? sizes[Math.floor(Math.random() * sizes.length)] 
        : '';
      
      const sizeText = size ? ` - ${size}` : '';
      const colorText = ` - ${color}`;
      const brandText = `${brand} `;
      
      const variationPrice = template.price * (0.85 + Math.random() * 0.3);
      const rating = 3 + Math.random() * 2;
      const stock = Math.floor(Math.random() * 50) + 5;
      
      products.push({
        id: `product-${products.length + 1}`,
        name: `${brandText}${template.name}${colorText}${sizeText}`,
        description: template.description,
        price: Math.round(variationPrice * 100) / 100,
        category: template.category,
        image: template.image,
        rating: Math.round(rating * 10) / 10,
        stock,
      });
      
      // Break out early if we have enough products
      if (products.length >= 100) break;
    }
    if (products.length >= 100) break;
  }

  return products;
};