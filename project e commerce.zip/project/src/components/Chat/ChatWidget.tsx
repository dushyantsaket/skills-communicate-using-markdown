import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Minimize2, Maximize2, Send } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import ChatMessage from './ChatMessage';
import { ChatMessage as ChatMessageType } from '../../types';
import { useChatStore } from '../../store/chatStore';
import { useProductSearch } from '../../hooks/useProductSearch';

const ChatWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  const { messages, addMessage } = useChatStore();
  const { searchProducts, isSearching } = useProductSearch();

  const toggleChat = () => {
    setIsOpen(!isOpen);
    setIsMinimized(false);
  };

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && !isMinimized) {
      inputRef.current?.focus();
    }
  }, [isOpen, isMinimized]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const processUserMessage = async (message: string) => {
    // Add user message to chat
    const userMessage: ChatMessageType = {
      id: uuidv4(),
      text: message,
      sender: 'user',
      timestamp: new Date(),
    };
    addMessage(userMessage);

    // Process the message (simple keyword-based intent detection for demo)
    const lowerMessage = message.toLowerCase();
    
    // Initial bot response
    let botText = "I'm not sure how to help with that. Try asking about our products or search for something specific.";
    let products = undefined;
    
    // Simple intent detection
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
      botText = "Hello! How can I help you today? You can ask about our products or search for specific items.";
    } else if (lowerMessage.includes('help')) {
      botText = "I can help you find products, check prices, and answer questions about our store. What are you looking for today?";
    } else if (
      lowerMessage.includes('search') || 
      lowerMessage.includes('find') || 
      lowerMessage.includes('looking for') ||
      lowerMessage.includes('show me')
    ) {
      // Extract search terms (naive approach for demo)
      const searchTerms = message.replace(/search|find|looking for|show me/gi, '').trim();
      
      if (searchTerms) {
        botText = `Let me search for "${searchTerms}" for you...`;
        addMessage({
          id: uuidv4(),
          text: botText,
          sender: 'bot',
          timestamp: new Date(),
        });

        try {
          // Perform the search
          const results = await searchProducts(searchTerms);
          
          if (results.length > 0) {
            botText = `Here are some ${searchTerms} products I found:`;
            products = results;
          } else {
            botText = `I couldn't find any products matching "${searchTerms}". Can I help you find something else?`;
          }
        } catch (error) {
          console.error('Search error:', error);
          botText = "I'm having trouble searching right now. Please try again later.";
        }
      } else {
        botText = "What would you like me to search for?";
      }
    }

    // Add bot response
    const botMessage: ChatMessageType = {
      id: uuidv4(),
      text: botText,
      sender: 'bot',
      timestamp: new Date(),
      products,
    };
    
    // Slight delay to simulate bot thinking
    setTimeout(() => {
      addMessage(botMessage);
    }, 1000);
  };

  const handleSendMessage = async () => {
    if (inputValue.trim() === '') return;
    
    await processUserMessage(inputValue);
    setInputValue('');
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {/* Chat Button */}
      {!isOpen && (
        <button
          onClick={toggleChat}
          className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full shadow-lg transition-all duration-300 flex items-center justify-center"
          aria-label="Open chat"
        >
          <MessageSquare className="h-6 w-6" />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div 
          className={`bg-white rounded-lg shadow-xl transition-all duration-300 flex flex-col ${
            isMinimized ? 'h-14 w-72' : 'h-96 w-80 sm:w-96'
          }`}
        >
          {/* Chat Header */}
          <div className="bg-blue-600 text-white px-4 py-3 rounded-t-lg flex justify-between items-center">
            <div className="flex items-center">
              <MessageSquare className="h-5 w-5 mr-2" />
              <h3 className="font-medium">ShopChat Assistant</h3>
            </div>
            <div className="flex space-x-2">
              <button 
                onClick={toggleMinimize} 
                className="text-blue-100 hover:text-white transition-colors"
                aria-label={isMinimized ? "Maximize chat" : "Minimize chat"}
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </button>
              <button 
                onClick={toggleChat} 
                className="text-blue-100 hover:text-white transition-colors"
                aria-label="Close chat"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Chat Body - only shown when not minimized */}
          {!isMinimized && (
            <>
              <div className="flex-1 p-4 overflow-y-auto">
                {messages.length === 0 ? (
                  <div className="text-center text-gray-500 mt-4">
                    <p>Welcome to ShopChat!</p>
                    <p className="text-sm mt-2">How can I help you today?</p>
                  </div>
                ) : (
                  messages.map((message) => (
                    <ChatMessage key={message.id} message={message} />
                  ))
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Chat Input */}
              <div className="border-t p-3 flex items-center">
                <input
                  ref={inputRef}
                  type="text"
                  value={inputValue}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyDown}
                  placeholder="Type your message..."
                  className="flex-1 px-3 py-2 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  disabled={isSearching}
                />
                <button
                  onClick={handleSendMessage}
                  disabled={inputValue.trim() === '' || isSearching}
                  className="bg-blue-600 text-white px-3 py-2 rounded-r-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  {isSearching ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default ChatWidget;