import React from 'react';
import { formatRelativeTime } from '../../utils/formatters';
import { ChatMessage as ChatMessageType } from '../../types';
import ProductCarousel from '../Products/ProductCarousel';

interface ChatMessageProps {
  message: ChatMessageType;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const { text, sender, timestamp, products } = message;
  const isBot = sender === 'bot';

  return (
    <div 
      className={`mb-4 ${isBot ? 'mr-12' : 'ml-12'} flex flex-col`}
    >
      <div 
        className={`px-4 py-2 rounded-lg ${
          isBot 
            ? 'bg-gray-100 text-gray-800 rounded-br-none' 
            : 'bg-blue-600 text-white rounded-bl-none self-end'
        }`}
      >
        <p className="text-sm">{text}</p>
      </div>
      
      {products && products.length > 0 && (
        <div className="mt-2">
          <ProductCarousel products={products} />
        </div>
      )}
      
      <div 
        className={`text-xs text-gray-500 mt-1 ${
          isBot ? '' : 'text-right'
        }`}
      >
        {formatRelativeTime(timestamp)}
      </div>
    </div>
  );
};

export default ChatMessage;