import React from 'react';
import { ShoppingCart, Heart } from 'lucide-react';
import { Product } from '../../types';

interface ProductCardProps {
  product: Product;
  compact?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, compact = false }) => {
  const { name, price, image, category, rating } = product;
  
  // Render stars for the rating
  const renderStars = () => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span 
          key={i} 
          className={`text-sm ${i <= rating ? 'text-yellow-400' : 'text-gray-300'}`}
        >
          ★
        </span>
      );
    }
    return stars;
  };

  if (compact) {
    return (
      <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200 hover:shadow-md transition-shadow">
        <div className="flex">
          <div className="h-20 w-20 bg-gray-100 flex-shrink-0">
            <img 
              src={image} 
              alt={name} 
              className="h-full w-full object-cover" 
            />
          </div>
          <div className="p-2 flex flex-col justify-between flex-grow">
            <div>
              <h3 className="text-sm font-medium text-gray-900 line-clamp-1">{name}</h3>
              <p className="text-xs text-gray-500 line-clamp-1">{category}</p>
            </div>
            <div className="flex justify-between items-center mt-1">
              <span className="text-sm font-bold">${price.toFixed(2)}</span>
              <button className="text-blue-600 hover:text-blue-800 p-1 rounded-full transition-colors">
                <ShoppingCart className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      {/* Product Image */}
      <div className="h-48 bg-gray-100">
        <img 
          src={image} 
          alt={name} 
          className="h-full w-full object-cover" 
        />
      </div>
      
      {/* Product Info */}
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-medium text-gray-900">{name}</h3>
            <p className="text-sm text-gray-500">{category}</p>
          </div>
          <button className="text-gray-400 hover:text-red-500 p-1 rounded-full transition-colors">
            <Heart className="h-5 w-5" />
          </button>
        </div>
        
        <div className="mt-2 flex items-center">
          {renderStars()}
          <span className="ml-1 text-xs text-gray-500">({rating.toFixed(1)})</span>
        </div>
        
        <div className="mt-4 flex justify-between items-center">
          <span className="text-xl font-bold text-gray-900">${price.toFixed(2)}</span>
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-md flex items-center text-sm transition-colors">
            <ShoppingCart className="h-4 w-4 mr-1" />
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;