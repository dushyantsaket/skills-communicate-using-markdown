import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { v4 as uuidv4 } from 'uuid';
import { ChatMessage, ChatSession } from '../types';

interface ChatState {
  currentSessionId: string;
  sessions: Record<string, ChatSession>;
  messages: ChatMessage[];
  addMessage: (message: ChatMessage) => void;
  clearMessages: () => void;
  startNewSession: () => void;
}

export const useChatStore = create<ChatState>()(
  persist(
    (set, get) => ({
      currentSessionId: uuidv4(),
      sessions: {},
      messages: [],
      
      addMessage: (message: ChatMessage) => {
        set((state) => {
          const { currentSessionId, sessions } = state;
          const currentSession = sessions[currentSessionId] || {
            id: currentSessionId,
            messages: [],
            createdAt: new Date(),
            updatedAt: new Date(),
          };
          
          const updatedMessages = [...state.messages, message];
          const updatedSession = {
            ...currentSession,
            messages: updatedMessages,
            updatedAt: new Date(),
          };
          
          return {
            messages: updatedMessages,
            sessions: {
              ...sessions,
              [currentSessionId]: updatedSession,
            },
          };
        });
      },
      
      clearMessages: () => {
        set((state) => {
          const { currentSessionId, sessions } = state;
          const currentSession = sessions[currentSessionId] || {
            id: currentSessionId,
            messages: [],
            createdAt: new Date(),
            updatedAt: new Date(),
          };
          
          const updatedSession = {
            ...currentSession,
            messages: [],
            updatedAt: new Date(),
          };
          
          return {
            messages: [],
            sessions: {
              ...sessions,
              [currentSessionId]: updatedSession,
            },
          };
        });
      },
      
      startNewSession: () => {
        const newSessionId = uuidv4();
        set({
          currentSessionId: newSessionId,
          messages: [],
          sessions: {
            ...get().sessions,
            [newSessionId]: {
              id: newSessionId,
              messages: [],
              createdAt: new Date(),
              updatedAt: new Date(),
            },
          },
        });
      },
    }),
    {
      name: 'chat-store',
      partialize: (state) => ({
        sessions: state.sessions,
        currentSessionId: state.currentSessionId,
      }),
    }
  )
);