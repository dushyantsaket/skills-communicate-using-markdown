# E-commerce Sales Chatbot - Backend

This is the backend server for the E-commerce Sales Chatbot project. It provides a RESTful API for the frontend to interact with, including product search, user authentication, and chatbot functionality.

## Features

- **User Authentication**: Simple login endpoint with JWT token generation
- **Product Management**: Endpoints for retrieving products, filtering, and searching
- **Chatbot Processing**: Natural language processing to handle user queries
- **Mock Database**: In-memory storage of products and users for demonstration purposes

## API Endpoints

### Authentication

- `POST /api/auth/login`: Authenticate a user and return a JWT token

### Products

- `GET /api/products`: Get all products with optional filtering
- `GET /api/products/:id`: Get a specific product by ID

### Chat

- `POST /api/chat/message`: Process a chat message and return a response

## Setup and Running

1. Make sure you have Python installed
2. Install dependencies: `pip install flask flask-cors`
3. Run the server: `python app.py`

The server will start on port 5000 by default.

## Implementation Details

This backend implementation uses:
- Flask for the web framework
- In-memory data structures for storing products and users
- Simple keyword-based intent detection for chatbot functionality

In a production environment, this would be replaced with:
- A proper database (PostgreSQL, MongoDB, etc.)
- Advanced NLP using libraries like NLTK or spaCy
- Proper authentication with password hashing
- Additional security measures

## Notes

This is a simplified implementation for demonstration purposes. It does not include all the features that would be present in a production e-commerce system.