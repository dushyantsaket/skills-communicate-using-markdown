from flask import Flask, jsonify, request
import json
import os
import random
from flask_cors import CORS
import time
from datetime import datetime, timedelta

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load mock products data
def load_products():
    # In a real application, this would come from a database
    products = []
    categories = ["Electronics", "Clothing", "Home & Kitchen", "Books", "Beauty"]
    
    for i in range(1, 101):
        category = random.choice(categories)
        rating = round(random.uniform(3.0, 5.0), 1)
        price = round(random.uniform(10.0, 500.0), 2)
        
        product = {
            "id": f"product-{i}",
            "name": f"Product {i}",
            "description": f"This is a description for product {i}. It belongs to the {category} category.",
            "price": price,
            "category": category,
            "image": f"https://picsum.photos/seed/{i}/300/300",
            "rating": rating,
            "stock": random.randint(0, 50)
        }
        products.append(product)
    
    return products

PRODUCTS = load_products()
USERS = {
    "user@example.com": {
        "id": "1",
        "username": "demouser",
        "email": "user@example.com",
        "password": "password123"  # In a real app, this would be hashed
    }
}

# Authentication routes
@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    # Simple authentication logic
    user = USERS.get(email)
    
    if not user or user['password'] != password:
        return jsonify({
            "success": False,
            "error": "Invalid credentials"
        }), 401
    
    # In a real app, you would generate a proper JWT
    user_data = {
        "id": user["id"],
        "username": user["username"],
        "email": user["email"]
    }
    
    # Simulate token creation
    token = "mock-jwt-token-" + str(int(time.time()))
    
    return jsonify({
        "success": True,
        "data": {
            "user": user_data,
            "token": token
        }
    })

# Product routes
@app.route('/api/products', methods=['GET'])
def get_products():
    # Get query parameters
    search = request.args.get('search', '').lower()
    category = request.args.get('category', '')
    min_price = float(request.args.get('min_price', 0))
    max_price = float(request.args.get('max_price', 10000))
    min_rating = float(request.args.get('min_rating', 0))
    
    # Apply filters
    filtered_products = PRODUCTS
    
    if search:
        filtered_products = [p for p in filtered_products if 
                             search in p['name'].lower() or 
                             search in p['description'].lower() or
                             search in p['category'].lower()]
    
    if category:
        filtered_products = [p for p in filtered_products if p['category'] == category]
    
    filtered_products = [p for p in filtered_products if 
                         p['price'] >= min_price and 
                         p['price'] <= max_price and
                         p['rating'] >= min_rating]
    
    return jsonify({
        "success": True,
        "data": {
            "products": filtered_products,
            "totalResults": len(filtered_products)
        }
    })

@app.route('/api/products/<product_id>', methods=['GET'])
def get_product(product_id):
    product = next((p for p in PRODUCTS if p['id'] == product_id), None)
    
    if not product:
        return jsonify({
            "success": False,
            "error": "Product not found"
        }), 404
    
    return jsonify({
        "success": True,
        "data": product
    })

# Chat routes
@app.route('/api/chat/message', methods=['POST'])
def process_chat_message():
    data = request.json
    message = data.get('message', '')
    
    # Simple intent detection
    message_lower = message.lower()
    
    # Default response
    response = {
        "text": "I'm not sure how to help with that. Try asking about our products or search for something specific.",
        "products": []
    }
    
    # Greeting intent
    if any(word in message_lower for word in ['hello', 'hi', 'hey']):
        response["text"] = "Hello! How can I help you today? You can ask about our products or search for specific items."
    
    # Help intent
    elif 'help' in message_lower:
        response["text"] = "I can help you find products, check prices, and answer questions about our store. What are you looking for today?"
    
    # Search intent
    elif any(word in message_lower for word in ['search', 'find', 'show', 'looking for']):
        # Extract search terms (simple approach)
        search_terms = message_lower
        for term in ['search', 'find', 'show', 'looking for', 'me']:
            search_terms = search_terms.replace(term, '')
        
        search_terms = search_terms.strip()
        
        if search_terms:
            # Search for products
            matching_products = []
            for product in PRODUCTS:
                if (search_terms in product['name'].lower() or 
                    search_terms in product['description'].lower() or 
                    search_terms in product['category'].lower()):
                    matching_products.append(product)
            
            # Limit to 5 products
            matching_products = matching_products[:5]
            
            if matching_products:
                response["text"] = f"Here are some products related to '{search_terms}':"
                response["products"] = matching_products
            else:
                response["text"] = f"I couldn't find any products matching '{search_terms}'. Can I help you find something else?"
        else:
            response["text"] = "What would you like me to search for?"
    
    # Price intent
    elif 'price' in message_lower or 'cost' in message_lower or 'how much' in message_lower:
        response["text"] = "I can help you find products in your price range. What's your budget?"
    
    # Add a random delay to simulate processing
    time.sleep(random.uniform(0.5, 1.5))
    
    return jsonify({
        "success": True,
        "data": response
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)